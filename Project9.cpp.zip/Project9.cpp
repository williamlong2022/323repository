#include<iostream>
#include<fstream>
#include<string>
using namespace std;

class hNode{
public:
	int ID;
	int cost;
	hNode* next;
	hNode(int id, int c){
		ID = id;
		cost = c;

	}

	void printHNode(hNode* node, ofstream& fw1){
		fw1<<"(";
		fw1<<node->ID;
		fw1<<",";
		fw1<<node->cost;
		fw1<<")";

	}
};
class AstarNode{
public:
	int ID;
	int numNodesRemain;
	int gStar;
	int hStar;
	int fStar;
	AstarNode* next;
	AstarNode* parent;

	AstarNode(int ID1,int numNodesRemain1,int gStar1,int medianEdgeCost1, AstarNode* parent1){
		ID = ID1;
		numNodesRemain = numNodesRemain1;
		gStar = gStar1;
		 hStar = medianEdgeCost1*numNodesRemain1;

		 fStar =gStar+ hStar; 
		parent = parent1;
		next = NULL;


	}
	void printAstarNode(AstarNode* node, ofstream& fw1){
		fw1<<"(";
		fw1<<node->ID;
		fw1<<",";
		fw1<<node->numNodesRemain;
		fw1<<",";
		fw1<<node->gStar;
		fw1<<",";
		fw1<<node->hStar;
		fw1<<",";
		fw1<<node->fStar;
		fw1<<",";
		if(node->parent != NULL){fw1<<node->parent->ID;}
		else {fw1<<"NULL";}
		fw1<<")";

	}
};

class AStarSearch{
public:
	int numNodes;
	int StartID;
	hNode** hLList;
	AstarNode* Open;
	AstarNode* Close;
	int medianEdgeCost;

	void createAStarSearch(ifstream& fr){
		int c;
		if(fr>>c){
			numNodes = c;
		}

		hLList = new hNode* [numNodes+1];
		for(int i=0;i<=numNodes;i++){
			hLList[i] = NULL;
		}
		Open = new AstarNode(999,999,999,999,NULL);
		Close = new AstarNode(999,999,999,999,NULL);

	}

	void loadGraph(ifstream& fr){
		int m;
		int n;
		int c;
		while(fr>>m && fr>>n && fr>>c){
			hashInsert(m,n,c);
			hashInsert(n,m,c);
		}


	}

	void hashInsert(int ID1,int ID2,int cost){
		hNode* newNode = new hNode(ID2,cost);

		if(hLList[ID1] == NULL){
			hLList[ID1] = newNode;
		}
		else{
			newNode->next = hLList[ID1]->next;
			hLList[ID1]->next = newNode;
		}

	}

	void printtHshTable(ofstream& fw){
		
		for(int i = 1;i<= numNodes;i++){
			if(hLList[i] != NULL){
				fw<<"hLList[";
				fw<<i;
				fw<<"]";
				hNode *temp = hLList[i];
			while(temp != NULL){
				fw<<"-->";
				temp->printHNode(temp,fw);
				temp = temp->next;
			}
			fw<<endl;

			}
		}
		
	}

	void insertionSort(int* arr,int n){
		int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;
 
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }

	}


	int getMedian(ifstream& fr,ifstream& fr1){
		int sum = 0;
		int a;
		int b;
		int c;
		int d;
		int i=0;
	if(fr>>a){
		while(fr>>b && fr>>c && fr>>d){
			sum++;
		}

	}
	int* array = new int[sum];
	if(fr1>>a){
		while(fr1>>b && fr1>>c && fr1>> d){
			array[i] = d;
			i++;
		}
	}
	insertionSort(array,sum);
	if(sum%2 != 0){
		return array[sum/2];
	}
	else {
		return (int)(array[sum/2]+array[(sum/2)-1])/2;
	}

	}

// 	AstarNode* findClose(int ID){
// 		AstarNode* spot = Close->next;
// 		while(spot != NULL && ID>spot->ID){
// 			spot == spot->next;
// 		}
// 		if(ID = spot->ID){
// 			return spot;
// 		}
// 		else{return NULL;}

// 	}

// AstarNode* findOpen(int ID){
// 		AstarNode* spot = Open->next;
// 		while(spot != NULL && ID != spot->ID){
// 			spot = spot->next;
// 		}
// 		if(fStar == spot->fStar){
// 			return spot;
// 		}
// 		else{return NULL;}

// 	}

	void OpenInsert(AstarNode* temp){
		AstarNode* spot = Open;
		while(spot->next != NULL && temp->fStar > spot->next->fStar){
			spot = spot->next;

		}
		temp->next = spot->next;
		 spot->next = temp;

	}

	// void CloseInsert(AstarNode* temp){
	// 	AstarNode* spot = Close;
	// 	while(spot->next != NULL && temp->ID>spot->next->ID){
	// 		spot = spot->next;

	// 	}
	// 	temp->next = spot->next;
	// 	spot->next = temp;

	// }

	void printList(AstarNode* Node,ofstream& fw1){
		AstarNode* temp = Node;
		while(temp->next != NULL){
			temp->printAstarNode(temp->next,fw1);
			fw1<<"->";
			temp = temp->next;
		}
		fw1<<"NULL";
		fw1<<endl;

	}

	AstarNode* removeOpen(){
		AstarNode* spot = Open->next;
		if(spot == NULL){
			return NULL;
		}
		else{
		Open->next = spot->next;
		spot->next = NULL;
		return spot;
		}
	}

	bool checKGoal(AstarNode* Node,ofstream& fw){
		// AstarNode* n = new AstarNode(222,333,444,555,NULL);
		fw<<"check node";
		fw<<endl;
		 Node->printAstarNode(Node,fw);

		if(Node->ID != StartID){
			return false;
		}
		else if(visitedAll(Node,fw) == true){
			return true;
		}else{
			return false;
		}


	}



	bool visitedAll(AstarNode* Node,ofstream& fw1){


		int* visitedArray = new int[numNodes+1];
		AstarNode* checker = Node->parent;

		while(checker != NULL){
			int id = checker->ID;
		visitedArray[id]++;
		if(visitedArray[id]>1){
			exit(0);
		}
		checker = checker->parent;

		}
		for(int i=1;i<= numNodes;i++){
			fw1<<visitedArray[i];
			fw1<<",";

		}fw1<<endl;
		for(int j=1;j<=numNodes;j++){
			if(visitedArray[j] <= 0){
				return false;
			}
		}
		return true;
		
}




	bool checkVisited(AstarNode* currentNode,hNode* nextNode){

		int n=1;
		AstarNode* checker = currentNode->parent;

		 while(checker != NULL){
		 	if(n == numNodes-1 && checker->ID == nextNode->ID){
		 		return false;
		 	}
		 	if(checker->ID == nextNode->ID){
		 		return true;
		 	}
		 	checker = checker->parent;
		 	n++;
		 	


		 }
		 return false;
		 


	}

	// void replaceOpen(AstarNode* childNode,AstarNode* openSpot){


	// }



	void expansion(AstarNode* currentNode){

		int nodeID = currentNode->ID;
		hNode* nextNode = hLList[nodeID];
		while(nextNode != NULL){
		if(nextNode != NULL && checkVisited(currentNode,nextNode) == false){
			int ID = nextNode->ID;
			int numNodesRemain = currentNode->numNodesRemain - 1;
			int gStar = currentNode->gStar + nextNode->cost;
			AstarNode* childNode = new AstarNode(ID,numNodesRemain,gStar,medianEdgeCost, currentNode);

			OpenInsert(childNode);
			
		}
		nextNode = nextNode->next;
			// AstarNode* openSpot = findOpen(childNode->fStar);
			// AstarNode* closeSpot = findClose(ID);


			// if(openSpot == NULL && closeSpot == NULL){
			// 	OpenInsert(childNode);
			// }
			// else if(openSpot != NULL && closeSpot != NULL){
			// 	fw<<"something is wrong, openSpot != NULL && closeSpot !- NULL";
			// 	fw1<<"something is wrong, openSpot != NULL && closeSpot !- NULL";
			// 	return 0;
			// }
			// else if()

		} 

	}

	void printRout(AstarNode* node,ofstream& fw){
		// fw<<"Start Node=";
		// fw<<node->ID;
		// fw<<endl;
		// fw<<"the solution foud:  ";
		AstarNode* spot = node;

		if(spot != NULL && spot->parent != NULL){
			printRout(spot->parent,fw);
			fw<<"->";
			fw<<spot->ID;

	}
	else{
		fw<<spot->ID;
	}

		// fw<<spot->ID;
		// fw<<"  cost = ";
		// fw<<node->fStar;
		// fw<<endl;
		// fw<<"--------------------------------------------------------";
		// fw<<endl;

	}





};



int main(int argc, char** argv){
	string in = argv[1];
	string out = argv[2];
	string out1 = argv[3];


	ifstream fr;
	ifstream fr1;

	ofstream fw;
	ofstream fw1;

	fr.open(in);
	fw.open(out);
	fw1.open(out1);

	AStarSearch a ;
	a.createAStarSearch(fr);
	a.loadGraph(fr);
	a.printtHshTable(fw);
	fw<<endl;

	fr.close();

	fr.open(in);
	fr1.open(in);
	a.medianEdgeCost = a.getMedian(fr,fr1);
	// cout<<a.medianEdgeCost;

	a.StartID =1;

	fw<<"There are ";
	fw<<a.numNodes;
	fw<<"nodes in thr inout graph.Below are the solution rout for each node in the graph:";
	fw<<endl;

   while(a.StartID <= a.numNodes){

	 AstarNode* StartNode = new AstarNode(a.StartID,a.numNodes,0,a.medianEdgeCost,NULL);
	


	   a.OpenInsert(StartNode);
	fw1<<"Opne list after insertStarnode";
	fw1<<endl;
	a.printList(a.Open,fw1);
	bool foundSolution = false;
	AstarNode* currentNode = a.removeOpen();

	while(foundSolution == false && currentNode != NULL){
		 
	// fw1<<"Openlist after remove its front node";
	fw1<<endl;
	fw1<<"Open List after remove its front Node";
	fw1<<endl;
	a.printList(a.Open,fw1);

	if(currentNode != NULL){
		if(a.checKGoal(currentNode,fw1)== true){
			fw<<"A solution found";
			fw<<endl;
		fw<<"Start Node=";
		fw<<currentNode->ID;
		fw<<endl;
		fw<<"the solution foud:  ";
			a.printRout(currentNode,fw);
		// fw<<currentNode->ID;
		fw<<"  cost = ";
		fw<<currentNode->fStar;
		fw<<endl;
		fw<<"--------------------------------------------------------";
		fw<<endl;
			fw<<endl;


			foundSolution = true;
			a.Open = new AstarNode(9999,9999,9999,9999,NULL);
		}
		else{
			a.expansion(currentNode);
			currentNode = a.removeOpen();
		}
	}
	

	}
	// cout<<foundSolution;
	// cout<<endl;
	// int n;
	// if(currentNode == NULL){
	// 	n=0;
	// }
	// else{n = 1;}
	// cout<<n;
	// cout<<endl;
	// // cout<<endl;
	// cout<<a.StartID;
	// cout<<endl;
	// cout<<endl;



	if(foundSolution == false || currentNode == NULL)
	{
	fw<<"no solution froem startID=";
	fw<<a.StartID;
	}
	// a.printtHshTable(fw);
	a.StartID++;
	   }

   fr.close();
   fw.close();
   fw1.close();










	// a.StartID++;
	// AstarNode* StartNode = new AstarNode(a.StartID,a.numNodes,0,a.medianEdgeCost,NULL);
	// a.OpenInsert(StartNode);
	// fw1<<"Opnelist after insertStarnode";
	// a.printList(Open,fw1);
	// bool foundSolution = false;

	// while(foundSolution == false && currentNode != NULL){
	// 	AstarNode* currentNode = a.removeOpen();
	// fw1<<"Openlist after remove its front node";
	// a.printList(Open,fw1);

	// if(currentNode != NUL){
	// 	if(checKGoal(currentNode,fw1)== true){
	// 		fw<<"A solution found";
	// 		fw<<endl;
	// 		a.printRout(currentNode,fw);
	// 		foundSolution = true;
	// 	}
	// 	else{
	// 		expansion(currentNode);
	// 	}
	// }

	// }
	// fw<<"no solution froem startID=";
	// fw<<a.StartID;




	// AstarNode* currentNode = a.removeOpen();
	// fw1<<"Openlist after remove its front node";
	// a.printList(Open,fw1);

	// if(currentNode != NUL){
	// 	if(checKGoal(currentNode,fw1)== true){
	// 		fw<<"A solution found";
	// 		fw<<endl;
	// 		a.printRout(currentNode,fw);
	// 		foundSolution = true;
	// 	}
	// 	else{
	// 		expansion(currentNode);
	// 	}
	// }

	
	// cout<<a.getMedian(fr,fr1);

	 // AstarNode* node = new AstarNode(2,1,1,2,NULL);

	 
	 // a.expansion(node);
	 //  a.checKGoal(node,fw);
	 //   a.printList(a.Open,fw);
	  // a.visitedAll(node,fw);
	 // a.printRout(node,fw);

}











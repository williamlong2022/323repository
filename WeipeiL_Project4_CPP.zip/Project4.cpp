#include <iostream>
#include <fstream>
using namespace std;

class listNode{
  public:
  string data;
  listNode *next;

  listNode(string d){
    data = d;
    next = NULL;
  }

void printNode(listNode *node,fstream& file){
 
    file<<"(";
    file<<node->data;
    file<<",";
    if(node->next != NULL){
    file<<node->next->data;
    }
    else{
      file<<"NULL";
    }
    file<<")";
    file<<"-->";


}
friend class LLStack;
friend class LLQueue;
friend class RSort;

};

class LLStack{
  public:
  listNode *top;

  LLStack(){
    top = new listNode("dummyNode");
    top -> next = NULL;
  }

  void push(string a){
    listNode *temp = new listNode(a);
    temp->next = top ->next;
    top->next = temp;
  }

  bool isEmpty(){
    return top->next == NULL;
  }

  listNode* pop(){
    if(isEmpty()){
      exit(1);
    }
    listNode *temp = top->next;
    top->next = temp->next;
    return temp;
  }
 

  void printStack(fstream& fw){
    listNode* temp = top;
    fw<<"the stack I build is:";
    while(temp != NULL){
      top->printNode(temp,fw);
      temp = temp->next;
    }
    fw<<"NULL";
    fw<<endl;

  }
  friend class RSort;

  
};

class LLQueue{
  public:
  listNode *head;
  listNode *tail;

  LLQueue(){
    head = tail = new listNode("dummyNode");
    head->next = NULL;
  }

  void insertQ(string a){
   
    listNode *temp = new listNode(a);
    tail->next = temp;
    tail= temp;
  }

  listNode* deleteHead(){
    if(head->next == NULL  ){  exit(1);}
    listNode* temp = head->next;
    head->next = temp->next;
    if(head->next==NULL){tail = head;}
    return temp;
  }

bool isEmpty(){
  return head->next == NULL;
}

void printQ(int i, int j,fstream& fw){
  fw<<"Table[";
  fw<<i;
  fw<<"]";
  fw<<"[";
  fw<<j;
  fw<<"]:";
listNode *temp = head;
while(temp != NULL){
  head->printNode(temp, fw);
  temp = temp->next;
}
fw<<"NULL";
fw<<endl;

}
friend class RSort;
friend int mian();

};

class RSort{
  public:

  LLQueue **hashTable;
  string data;
  int currentTable;
  int nextTable;
  int longestStringLength;
  int currentPosition;

  RSort(){
    hashTable = new LLQueue*[2];
    for(int i=0;i<2;i++){
      hashTable[i] = new LLQueue[256];
    }
  }

void firstReading(fstream& inFile,fstream& outFile2){
  outFile2<<"Performing first Reading";
  longestStringLength = 0;
  string w;
  while(inFile>>w){
    if(w.length()>longestStringLength) longestStringLength=w.length();
  }
  outFile2<<endl;

}

void padString(string& data){
  while(data.length()<longestStringLength){
    
      data = data +" ";
    
  }

  }

  LLStack* loadStack(fstream& in,fstream& out){
    out<<"Performing loadStack!";
    out<<endl;
    LLStack* S = new LLStack();
    string s;
    while(in>>s){
      padString(s);
     S->push(s);
      

    }
    return S;

  }

  char getChar(listNode* node,int Position){
  string s = node->data;
    return s.at(Position);
  }

  void printTable(int currentTable, fstream& fw){
    for(int i=0;i<256;i++){
      LLQueue Q = hashTable[currentTable][i];
      if(!Q.isEmpty()){
        Q.printQ(currentTable,i,fw);
        fw<<endl;
      }
    }
  }

  void printSortedData(int currentTable, fstream& fw){
    fw<<"After sorted :";
    fw<<endl;
    for(int i=0;i<256;i++){
      LLQueue Q = hashTable[currentTable][i];
      if(!Q.isEmpty()){
        listNode* temp = Q.head->next;
        while(temp!= NULL){
          fw<<temp->data;
          temp = temp->next;
          fw<<endl;

        }
       
      }
    }
  }

  
  

 void  moveStack(LLStack* S,int currentPosition,int currentTable,fstream& fw){
   fw<<"Performing moveStack";
   fw<<endl;
  
    while(!S->isEmpty()){
     listNode* node = S->pop();
    char a = getChar(node,currentPosition);
    int hashIndex = (int)a;

    hashTable[currentTable][hashIndex].insertQ(node->data);
   }
  }

  

  

};

int main(int argc,char* argv) {
  string inFile = argv[1];
  string outFile1 = argv[2];
  string outFile2 = argv[3];

  fstream inF;
  inF.open(inFile);

  fstream outF1;
  outF1.open(outFile1);

  fstream outF2;
  outF2.open(outFile2);


 RSort r ;
  
r.firstReading(inF,outF2);
 inF.close();

  fstream inF1;
  inF1.open(inFile);
  LLStack* S =r.loadStack(inF1,outF2);
  
  S->printStack(outF2);

  

  r.currentPosition = r.longestStringLength-1;
  cout<<r.currentPosition;
  r.currentTable = 0;

  r.moveStack(S,r.currentPosition,r.currentTable,outF2);

        r.printTable(0,outF2);
      

while(r.currentPosition>=1){
    r.currentPosition--;
     r.nextTable = (r.currentTable+1)%2;
    int currentQueue = 0;
    while(currentQueue<256){
      while(!r.hashTable[r.currentTable][currentQueue].isEmpty()){
      listNode* node = r.hashTable[r.currentTable][currentQueue].deleteHead();
       
      char x =r.getChar(node,r.currentPosition);
      int hashIndex = (int)x;
          

      r.hashTable[r.nextTable][hashIndex].insertQ(node->data);
      

      }
      currentQueue++;
    }
    outF2<<endl;
    r.printTable(r.nextTable,outF2);
    

    r.currentTable = r.nextTable;
  }
  
  r.printSortedData(r.currentTable,outF1);


 inF1.close();
 outF1.close();
 outF2.close();

}

package weipei;
import java.io.*;
import java.util.Scanner;
public class DijktraSSS{
  int numNodes;
  int sourceNode;
  int minNode;
  int currentNode;
  int costMatrix[][];
  int fatherAry[];
  int markedAry[];
  int bestCostAry[];

   public void createDijktraSSS(){
       costMatrix = new int[numNodes][numNodes];
      for(int i=1;i<numNodes;i++){
        for(int j=1;j<numNodes;j++){
          if(i==j) costMatrix[i][j]=0;
          else {costMatrix[i][j]=9999;}
        }

      }
       fatherAry = new int[numNodes];
       markedAry = new int[numNodes];
       bestCostAry = new int[numNodes];
   }

   void loadCostMatrix(Scanner input)throws IOException{   
    //  System.out.print(3);
    
     while(input.hasNext()){
      String c = input.next();
      String l = input.next();
      String count = input.next();

      int col = Integer.parseInt(c);
      int low = Integer.parseInt(l);
      int Count = Integer.parseInt(count);

      costMatrix[col][low]=Count;
  
      
     }
        
        
   }

   public void setBestCostAry(int source){
     for(int i = 1;i<numNodes;i++){
       bestCostAry[i] = costMatrix[source][i];
     }
     
   }

  public void setFatherAry(int source){
    for(int i=1;i<numNodes;i++){
      fatherAry[i]=source;
    }
  }

  public void setMarkedAry(int source){
    markedAry[source] = 1;
  }

  public  int findMinNode(){
    int minCost = 9999;
    int minNode = 0;
    
    for(int i=1;i<numNodes;i++){
      if(markedAry[i]==0){
        if(bestCostAry[i]<minCost){
          minCost = bestCostAry[i];
          minNode = i;
        }
      }

    }
    return minNode;
  }

  public int computeCost (int minNode, int currNode){
    return bestCostAry[minNode]+costMatrix[minNode][currNode];
  }

  void debugPrint(FileWriter fw)throws IOException{

  String line = System.getProperty("line.separator");
    fw.write("the sourceNode is ");
    fw.write(String.valueOf(sourceNode));
    fw.write(line);

    fw.write("the fatherArray is");
    fw.write(line);
    for(int i=1;i<numNodes;i++){
      fw.write(String.valueOf(fatherAry[i]));
      fw.write(" ");
    }
    fw.write(line);
    fw.write("the bestCostAry is");
      fw.write(line);
      for(int i=1;i<numNodes;i++){
      fw.write(String.valueOf(bestCostAry[i]));
      fw.write(" ");
    }

     fw.write(line);
    fw.write("the markedAry is");
      fw.write(line);
      for(int i=1;i<numNodes;i++){
      fw.write(String.valueOf(markedAry[i]));
      fw.write(" ");
    }
  }

  void  printShortestPath(int currentNode, int sourceNode, FileWriter fw)throws IOException{
    fw.write("the path from ");
    fw.write(String.valueOf(sourceNode));
    fw.write("to");
    fw.write(String.valueOf(currentNode));
    fw.write(":");
    int n = currentNode;

    if(fatherAry[currentNode]== sourceNode){
      fw.write(String.valueOf(currentNode));
      fw.write("<--");
    }
    while(fatherAry[currentNode] != sourceNode){
      fw.write(String.valueOf(currentNode));
      
      fw.write("<--");
      
      currentNode=fatherAry[currentNode];

      if(fatherAry[currentNode]== sourceNode){
      fw.write(String.valueOf(currentNode));
      fw.write("<--");}

    }
    fw.write(String.valueOf(sourceNode));
    fw.write(": cost =");
    fw.write(String.valueOf(bestCostAry[n]));
    String line = System.getProperty("line.separator");
    fw.write(line);

  }

  


}
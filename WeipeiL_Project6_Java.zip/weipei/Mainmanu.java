package weipei;


import java.io.*;
import java.util.Scanner;
class Mainmanu {
  public static void main(String[] args) throws IOException{
    String inFile = args[0];
    String SSSfile = args[1];
    String deBugFile = args[2];


     File inputFile = new File(inFile);
     File SSSfile1 = new File(SSSfile);
     File deBugFile1 = new File(deBugFile);

     FileWriter fw = new FileWriter(deBugFile1);
     FileWriter fw1 = new FileWriter(SSSfile1);

     FileReader fr = new FileReader(inputFile);
     Scanner input = new Scanner(fr);
     DijktraSSS S = new DijktraSSS() ;

     if(input.hasNext()){
       String num = input.next();
       int n = Integer.parseInt(num);
       
        S.numNodes = n+1;
    }
        S.createDijktraSSS();
        // System.out.print(S.markedAry[1]);
        S.loadCostMatrix(input);
          S.sourceNode =1;
        while(S.sourceNode<S.numNodes){
          S.setBestCostAry(S.sourceNode);
        S.setFatherAry(S.sourceNode);
        S.setMarkedAry(S.sourceNode);

        int sum = 0;
        while(sum < S.numNodes-1){
            S.minNode = S.findMinNode();
        S.markedAry[S.minNode]=1;

        S.debugPrint(fw);

        for(int current=1;current<S.numNodes;current++){
          if(S.markedAry[current] == 0){
                int newcost = S.computeCost(S.minNode,current);
                if(newcost<S.bestCostAry[current]){
                  S.bestCostAry[current] = newcost;
                  S.fatherAry[current] = S.minNode;
                  S.debugPrint(fw);
                }
          }
        }
          sum = 0;
        for(int i=1;i< S.numNodes;i++){
          sum += S.markedAry[i];
          // System.out.println(sum);
        }

        }
        for(int curr=1;curr<S.numNodes;curr++){
          S.printShortestPath(curr, S.sourceNode,fw1);
        }
        String line = System.getProperty("line.separator");
       fw1.write(line);

        S.sourceNode++;

        }
        
        // S.setBestCostAry(S.sourceNode);
        // S.setFatherAry(S.sourceNode);
        // S.setMarkedAry(S.sourceNode);

        // int sum = 0;
        // while(sum < S.numNodes-1){
        //     S.minNode = S.findMinNode();
        // S.markedAry[S.minNode]=1;

        // S.debugPrint(fw);

        // for(int current=1;current<S.numNodes;current++){
        //   if(S.markedAry[current] == 0){
        //         int newcost = S.computeCost(S.minNode,current);
        //         if(newcost<S.bestCostAry[current]){
        //           S.bestCostAry[current] = newcost;
        //           S.fatherAry[current] = S.minNode;
        //           S.debugPrint(fw);
        //         }
        //   }
        // }
        //   sum = 0;
        // for(int i=1;i< S.numNodes;i++){
        //   sum += S.markedAry[i];
        //   // System.out.println(sum);
        // }

        // }
        // for(int curr=1;curr<S.numNodes;curr++){
        //   S.printShortestPath(curr, S.sourceNode,fw1);
        // }


        // for(int source = 1;source<S.numNodes;source++){
        //   for(int curr=1;curr<S.numNodes;curr++){
        //     S.printShortestPath(curr,source,fw1);
        //   }
        // }
       
      
        // S.printShortestPath(5,1,fw1);
        
        // for(int i=1;i<S.numNodes;i++){
        //   for(int j=1;j<S.numNodes;j++){
        //     System.out.print(S.costMatrix[i][j]+" ");

        //   }
        //   System.out.println();
        // }
        // System.out.print(S.fatherAry[0]);
       

   fw.close(); 
   fw1.close();
  }
}
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Node{
public:
	int jobID;
	int jobTime;
	Node  *next;
	Node(int job,int jobT){
		jobID = job;
		jobTime = jobT;

	}
};

class schedule{

public:
	int numNodes;
	int numProcs;
	int procUsed;
	int currentTime;
	int jobTime;
	int totalJobTime;
	int *jobTimeAry;
	int **Matrix;
	int **Table;
	Node *OPEN;

	void initiSchedule(ifstream &fr,ifstream &fr1,ofstream  &fw1,int num){
		numProcs = num;
		OPEN = new Node(0,0);
		currentTime = 0;
		procUsed = 0;

		totalJobTime = 0;
		int n;
		int c;
		if(fr>>c && fr1 >> n ){
			numNodes = c;
			
			
		}

		jobTimeAry = new int[numNodes+1];

		Matrix = new int*[numNodes+1];
		for(int i=0;i < numNodes+1;i++){
			Matrix[i] = new int[numNodes+1];
		}

		
		totalJobTime = loadJobTimeAry(fr1);

		Table = new int*[numProcs+1];
		for(int i=0;i < numProcs+1;i++){
			Table[i] = new int[totalJobTime+1];
		}
		loadMatrix(fr);
		printMatrix(fw1);

		

	}

	void loadMatrix(ifstream &fr){
		int p;
		int d;
		Matrix[0][0] = numNodes;
		while(fr >> p && fr>>d){
		Matrix[p][d] = 1;
		Matrix[p][p] = 1;
		Matrix[d][d] =1;
		Matrix[0][d] += 1;
		Matrix[p][0] += 1;

		}

	}

	 int loadJobTimeAry(ifstream &fr1){
		int j;
		int t;
		int total;

		while(fr1>> j && fr1>> t){
			jobTimeAry[j] = t;
			total += t;
		}
		return total;
	}

	void printMatrix(ofstream &fw1){
		for(int i=0;i<numNodes+1;i++){
			for(int j=0;j<numNodes+1;j++){
				fw1<<Matrix[i][j];
				fw1<<" ";
			}
			fw1<<endl;
		}
 }

 int findOrphan(){
 	for(int i = 1;i<numNodes+1;i++){
 		if(Matrix[0][i] ==0 && Matrix[i][i] ==1){
 			Matrix[i][i] =2;
 			return i;
 		}
 	}
 	return -1;
 }

 void OpenInsert(int i){
 	
 	Node * temp = new Node(i,jobTimeAry[i]);
 	Node *spot = OPEN;
 	
 	
 	while(spot->next != NULL && i>spot->next->jobID){
 		spot = spot->next;
 		
 	}
 	temp->next = spot->next;
 	spot->next = temp;


 }

 void prinOPEN(ofstream &fw1){
 	Node *temp = OPEN;
 	while(temp != NULL){
 		fw1<<"<";
 		fw1<<temp->jobID;
 		fw1<<",";
 		fw1<<temp->jobTime;
 		fw1<<">";
 		fw1<<"-->";
 		temp = temp->next;

 	}
 	fw1<<"NULL";

 }

 int getNextProc(int currentTime){
 	for(int i=1;i<=numProcs;i++){
 		if(Table[i][currentTime] == 0){
 			return i;
 		}
 	}
 	return -1;

 }

 void fillOPEN(ofstream &fw1){
 	int ID = 1;
 	while(ID>0){
 	ID = findOrphan();
 	if(ID>0){
 	OpenInsert(ID);
 	prinOPEN(fw1);
 	fw1<<endl;

 }
 	}

 }

 bool isEmpty(){
 	return OPEN->next == NULL;
 }

 Node * deleteOPEN(){
 	Node *temp = OPEN->next;
 		if(!isEmpty()){
 			
 			OPEN->next = temp->next;
 		}
 		return temp;
 }

 void fillTable(){

 	 
 	
 	int availProc = 0;

 	while(availProc >=0 && !isEmpty() && procUsed < numNodes){
 		  availProc = getNextProc(currentTime);

 	if(availProc >=0){
 		Node *newJob = deleteOPEN();
 		putJobOnTable(availProc,currentTime,newJob->jobID,newJob->jobTime);
 		if(availProc>procUsed){
 			procUsed++;
 		}

 	}

 	}
 	
 }

 void putJobOnTable(int availProc,int currentTime,int jobID,int jobTime){
 	int Time = currentTime;
 	int EndTime = Time+jobTime;
 	while(Time<EndTime){
 		Table[availProc][Time] = jobID;
		Time++;
 	}
 }

 void printTable(ofstream &fw,int currentTime){
 	fw<<"Time: "; for(int i = 0;i<= currentTime;i++){fw<<i; fw<<" ";}
 	fw<<endl;

 	for(int j = 1;j<= procUsed;j++)
 		{fw<<"P"; fw<<j;fw<<":   "; 
 		for(int c =0;c<=currentTime;c++ ){
 			fw<<Table[j][c];
 			fw<<" ";
 		}
 		fw<<endl;
 }

 	

 }
 bool check(){
 	for(int j = 1;j<=numProcs;j++){
 		if(Table[j][currentTime] != 0)
 			return false;
 	}
 	return true;
 }

 bool cheeckCycle(){

 	return isEmpty() && !isGraphEmpty() && check();
 }

bool isGraphEmpty(){
	return Matrix[0][0]==0;
}

 void deleteDoneJobs(ofstream &fw1){
 	int proc = 0;

 	while(proc <= procUsed){
 		if(Table[proc][currentTime] <=0 && Table[proc][currentTime-1] >0){
 		int ID = Table[proc][currentTime-1];
 		deleteJob(ID);
 	}
 	printMatrix(fw1);
 	fw1<<endl; 
 	proc++;
 	}


 }

 void deleteJob(int jobID){
 	Matrix[jobID][jobID] = 0;
 	Matrix[0][0]--;
 	int j = 1;

 	while(j<=numNodes){
 		if(Matrix[jobID][j] > 0){
 			// Matrix[jobID][j] = 0;
 		Matrix[0][j]--;
 	}
 	j++;
 	}
 }

};
 
int main(int argc,char** argv){
	
	string in = argv[1];
	string in1 =argv[2];

	string out = argv[4];
	string out1 = argv[5];

	string num = argv[3];
	int numProcs = stoi(num);

	cout<<numProcs;

	ofstream fw;
	ofstream fw1;

	ifstream fr;
	ifstream fr1;

	fw.open(out);
	fw1.open(out1);

	fr.open(in);
	fr1.open(in1);

	schedule s;
	
	 s.initiSchedule(fr,fr1,fw1,numProcs);
	 
	 if(s.numProcs <=0){
	 	cout<<"need 1 or more processors";
	 	exit(1);
	 }else if (s.numProcs > s.numNodes){
	 	s.numProcs = s.numNodes;
	 }

	 while(!s.isGraphEmpty()){
	 s.fillOPEN(fw1);
	 // s.prinOPEN(fw1);
	 fw1<<endl;
	 // cout<<s.Table[1][0];
	 // cout<<s.getNextProc(s.currentTime);
	  s.fillTable();
	  s.printTable(fw,s.currentTime);
	  fw<<endl;
	  if(s.cheeckCycle()){
	 	fw<<"there is cycle in the graph";
	 	return 0;
		
	 }
	  s.currentTime++;

	 s.deleteDoneJobs(fw1);

	 

	 }


	   // s.printTable(fw,s.currentTime);

	 // s.fillOPEN(fw1);
	 // s.prinOPEN(fw1);
	 // s.fillTable();
	 // s.printTable(fw,s.currentTime);
	 // s.currentTime++;
	 // s.deleteDoneJobs(fw1);


	 // cout<<s.numNodes;
	// cout<<s.Matrix[6][1];
	 // cout<<"wojhdashfj";
	// s.loadMatrix(fr);
	// s.printMatrix(fw1);
	// cout<<s.findOrphan();
	// cout<<s.loadJobTimeAry(fr1);
	// cout<<s.Matrix[1][1];
	// cout<<s.Matrix[3][2];
	// cout<<s.Matrix[4][3];

	// cout<<s.Matrix[5][6];
	
	// cout<<s.Matrix[4][8];
	
}



















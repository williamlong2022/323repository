#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class Node {
public:
	int ID;
	Node *next;
	Node(int id){
		ID = id;

	}
	// Node(){
		
	// 	next = NULL;
	// }

};

class coloring{
public:
	int numNodes;
	int numUNcolor;
	Node **hLList;
	int *colorARY;

	void crecoloring(ifstream &fr){
		int c;
		if(fr>>c){numNodes = c;
		}

		numUNcolor = numNodes;
		colorARY = new int[numNodes+1];
		for(int j=1;j<=numNodes;j++){
			colorARY[j] = 0;
		}

		hLList = new Node*[numNodes+1];
		for(int i  =0;i<=numNodes;i++)
		{
			hLList[i]  = NULL;
		}

	}

	void loadGraph(ifstream &fr){
		int n;
		int m;

		while(fr>>n && fr>>m){
			hashInsert(n,m);
			hashInsert(m,n);
		}

	}

	void hashInsert(int i, int j){
		Node *newNode = new Node(j);
		
		

		if(hLList[i]==NULL){
			hLList[i] = newNode;
		} 
		else{
		newNode->next = hLList[i]->next;
		hLList[i]->next = newNode;
		}

		
 
	}

	void printHashTable(ofstream &fw1){
		int i =1;
		for(int i = 1;i<=numNodes;i++){
			if(hLList[1] != NULL){
				fw1<<"hLList[";
				fw1<<i;
				fw1<<"]";
				Node *temp = hLList[i];
			while(temp != NULL){
				fw1<<"-->";
				fw1<<temp->ID;
				temp = temp->next;
			}
			fw1<<endl;

			}
		}
	

}

	void method1(ofstream &fw,ofstream &fw1){
		fw<<"method1 was used to color the graph";
		fw<<endl;
		fw<<"beloe is the result of the color assignment";
		fw<<endl;
			int newColor = 0;
			while(numUNcolor >0){
				newColor++;
				int uncolorNodeID=0;
				for(int i=1;i<=numNodes;i++){
					 uncolorNodeID = getNextUncoloredNode(uncolorNodeID+1);
				if(uncolorNodeID >0){
				fw1<<newColor;
				fw1<< " ";
				fw1<<uncolorNodeID;
				fw1<<endl;
				if(uncolorNodeID>0 && chechNeighbors(uncolorNodeID,newColor)){
					colorARY[uncolorNodeID] = newColor;
					numUNcolor--;
					
				}
				}
				}
				printARY(fw1);
				fw1<<endl;

			}
			printARY(fw);

}

	void method2(ofstream &fw,ofstream &fw1){

		fw<<"method2 was used to color the graph";
		fw<<endl;
		fw<<"beloe is the result of the color assignment";
		fw<<endl;
		int newColor = 0;
		int lastUsedColor =0;
		int nextNodeID = 0;

		while(nextNodeID < numNodes){
			nextNodeID++;
		int nextUsedColor = 1;
		bool coloredFlag = false;

		while(coloredFlag == false && nextUsedColor <= lastUsedColor){
			if(lastUsedColor > 0 && chechNeighbors(nextNodeID,nextUsedColor)){
			colorARY[nextNodeID] = nextUsedColor;
			coloredFlag = true;
		}
		else{
			nextUsedColor++;

		}

		}
		if(coloredFlag == false){
			newColor++;
			colorARY[nextNodeID] = newColor;
			lastUsedColor++;
			fw1<<newColor;
			fw1<<" ";
			fw1<<lastUsedColor;
			fw1<<endl;

		}
		printARY(fw1);
		fw1<<endl;

		}
		printARY(fw);
		// nextNodeID++;
		// int nextUsedColor = 1;
		// bool coloredFlag = false;

		// while(coloredFlag == false && nextUsedColor <= lastUsedColor){
		// 	if(lastUsedColor > 0 && chechNeighbors(nextNodeID,nextUsedColor)){
		// 	colorARY[nextNodeID] = nextUsedColor;
		// 	coloredFlag = true;
		// }
		// else{
		// 	nextUsedColor++;

		// }

		// }
		// if(coloredFlag == false){
		// 	newColor++;
		// 	colorARY[nextNodeID] = newColor;
		// 	lastUsedColor++;
		// 	fw1<<newColor;
		// 	fw1<<" ";
		// 	fw1<<lastUsedColor;

		// }

		// if(lastUsedColor > 0 && chechNeighbors(nextNodeID,nextUsedColor)){
		// 	colorARY[nextNodeID] = nextUsedColor;
		// 	coloredFlag = true;
		// }
		// else{
		// 	nextUsedColor++;

		// }

}

	int getNextUncoloredNode(int j){
		for(int i =j;i<=numNodes;i++){
			if(colorARY[i] == 0){
				return i;
			}

		}
		return -1;


}

	bool chechNeighbors(int NodeID,int color){
		Node *nextNode = hLList[NodeID];
		while(nextNode != NULL){
			
		if(colorARY[nextNode->ID] == color){
			return false;
		}
		nextNode = nextNode->next;
		}
		return true;

	}

	void printARY(ofstream &fw1){
		fw1<<numNodes;
		fw1<<endl;
		for(int i=1;i<=numNodes;i++){
			fw1<<i;
			fw1<<" ";
			fw1<<colorARY[i];
			fw1<<endl;
		}
	}
};

int main(int argc, char** argv){
	string in = argv[1];
	string in1 = argv[2];
	string out = argv[3];
	string out1 = argv[4];

	int num = stoi(in1);

	ifstream fr;
	
	ofstream fw;
	ofstream fw1;

	fr.open(in);
	

	fw.open(out);
	fw1.open(out1);

	coloring c;
	c.crecoloring(fr);
	c.loadGraph(fr);
	c.printHashTable(fw1);
	if(num == 1){
		c.method1(fw,fw1);
	}
	else if(num == 2 ){
		c.method2(fw,fw1);
	}else{
		fw1<<"argv[2] only accept 1 or 2";
		return 0;
	}

	fr.close();
	fw.close();
	fw1.close();
	
	
	
	// c.hashInsert(1,2);
	// c.hashInsert(1,3);
	// c.hashInsert(1,4);
	// cout<<c.hLList[1]->ID;
	// Node *temp = c.hLList[1];
	// while(temp != NULL){
	// 	cout<<temp->ID;
	// 	temp = temp->next;
	// }

	
















}
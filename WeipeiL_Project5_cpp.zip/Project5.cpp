#include <iostream>
#include <fstream>
#include<string>
using namespace std;
class treeNode{
  public:
  string chStr;
  int count;
  string code;
  treeNode *left;
  treeNode *right;
  treeNode *next;

  treeNode(string ch,int c,string co){
        chStr = ch;
        code = co;
        count = c;
        left = NULL;
        right = NULL;
        next = NULL;
  }

  void printNode(treeNode* t, fstream& fw){  
    fw<<"(";
    fw<<t->chStr;
    fw<<",";
    fw<<t->count;
    fw<<",";
    fw<<t->code;
    fw<<",";
    if(t->left == NULL){
      fw<<"Null";
    }else{fw<<t->left->chStr;}
    fw<<",";

    if(t->right == NULL){
      fw<<"Null";
    }else{fw<<t->right->chStr;}
     fw<<",";
     
     if(t->next == NULL){ fw<<"Null";}
    else{ fw<<t->next->chStr;}
    fw<<")";
}
};

class linkedList{
  public:
  treeNode* listHead;

  linkedList(){
    listHead = new treeNode("dummy",0,"");
    
  }

  bool isEmpty(){
    return listHead->next ==NULL;
  }

  treeNode* findSpot(int count){
    treeNode* spot = listHead;
    while(spot->next != NULL && spot->next->count<count){
      spot = spot->next;
    }
    return spot;
  }
  void insertOneNode(treeNode* spot, treeNode* Node){
    // treeNode* spot = findSpot(Node->count);
    // treeNode* newNode = new treeNode(Node->chStr,Node->count,Node->code);
    Node->next = spot->next;
    spot->next = Node;
  }

  void printList(fstream& fw){
      treeNode* spot = listHead;
      while(spot != NULL){
        listHead->printNode(spot,fw);
        fw<<endl;
        spot = spot->next;
      }
  }
};

class Huffman{
  public:
  linkedList listNode;
  treeNode* Root;
  string codeTable[128];
  

  Huffman(){
     for(int i =0;i<128;i++){
    codeTable[i]="";
  }
  }

bool isLeaf(treeNode* t){
  return (t->left == NULL && t->right == NULL);
}

void constructHuffmanLList(fstream& fr,fstream& fw){
  fw<<"Enter constructHuffmanLList () method!";
  fw<<endl;
  
  string w;
  int c;
  while(fr>>w && fr>>c){
    treeNode* newNode = new treeNode(w,c,"");
    treeNode* spot = listNode.findSpot(c);
    listNode.insertOneNode(spot,newNode);
    listNode.printList(fw);
    fw<<endl;
  }
  fw<<"Leaving constructHuffmanLList () method! ";
  fw<<endl;
}

void constructHuffmanBinTree(fstream& fw){
  fw<<"Enter constructHuffmanBinTree () method! ";
  fw<<endl;
  treeNode* Node;
  while(listNode.listHead->next->next != NULL){
    
  treeNode* head = listNode.listHead->next;
    Node = new treeNode(head->chStr+head->next->chStr,head->count+head->next->count,"");
  // treeNode* Node;
  Node->left = head;
  Node->right = head->next;
  // Node->chStr= head->chStr+head->next->chStr;
  // Node->count = head->count+head->next->count;
 
treeNode* spot = listNode.findSpot(Node->count);
listNode.insertOneNode(spot,Node);
listNode.listHead->next = head->next->next;

listNode.printList(fw);
fw<<endl;
// fw<<"left";head->printNode(Node->left,fw);
// fw<<"right";head->printNode(Node->right,fw);
// fw<<endl;
   
  }
  Root = Node;
  // head->printNode(Node->left,fw);
  
  
  fw<<"Leaving constructHuffmanBinTree () method!";
  fw<<endl;
  fw<<endl;
}

void constructCharCode(treeNode* t,string code,fstream& fw){
  fw<< "In recursion of constructCodeTable (), code = ";fw<<code;
  fw<<endl;
  if(isLeaf(t)){
    t->code = code;
    int Index= (int)t->chStr.at(0);
    codeTable[Index] = code;
  }
  else{
    constructCharCode(t->left,code+"0",fw);
    constructCharCode(t->right,code+"1",fw);
  }
}

void printCodeTable(string T[128],fstream& fw){
  fw<<endl;
      for(int i=0;i<128;i++){
          if(T[i] != ""){
            char x = (char)i;
            fw<<x; fw<<" "; fw<<T[i]; fw<<endl;
          }
      }
}
void preOrderTraversal(treeNode* t,fstream& fw){
  
  if(t != NULL){
    t->printNode(t,fw);
    fw<<endl;
    preOrderTraversal(t->left,fw);
    preOrderTraversal(t->right,fw);
  }
}

void inOrderTraversal(treeNode* t,fstream& fw){
  if(t != NULL){
    preOrderTraversal(t->left,fw);
    t->printNode(t,fw);
    fw<<endl;
    preOrderTraversal(t->right,fw);
  }
}

void postOrderTraveesal(treeNode* t,fstream& fw){
  if(t != NULL){
    preOrderTraversal(t->left,fw);
    preOrderTraversal(t->right,fw);
    t->printNode(t,fw);
    fw<<endl;
  }
}

};
int main(int argc,char* argv) {
  string in = argv[1];
  string out = argv[2];
  string out1 = argv[3];

  // string in = "inFile";
  // string out = "outFile1";
  // string out1 = "outFile2";



  fstream fw;
  fstream fr;
  fstream fw1;

  fr.open(in);
  fw.open(out);
  fw1.open(out1);

   Huffman H;
   H.constructHuffmanLList(fr,fw);

   H.constructHuffmanBinTree(fw);
   
   H.constructCharCode(H.Root,"",fw);
   
   H.printCodeTable(H.codeTable,fw1);
   fw1<<"preOrderTraversal";
   fw1<<endl;
   H.preOrderTraversal(H.Root,fw1);
   fw1<<endl;
   fw1<<"inOrderTraversal";fw1<<endl;
   H.inOrderTraversal(H.Root, fw1);
   fw1<<endl;
   fw1<<"postOrderTraveesal";fw1<<endl;
   H.postOrderTraveesal(H.Root,fw1);

   fr.close();
   fw.close();
   fw1.close();

}
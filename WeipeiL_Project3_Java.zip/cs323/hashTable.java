package cs323;

import java.io.*;
import java.util.Scanner;
public class hashTable{
  
  char op;
  String firsName;
  String lastName;
  int bucketSize=13;
  listNode[] hashTable;


  public void createHash(){
    
    hashTable = new listNode[bucketSize];
   for(int i = 0;i<bucketSize;i++){
     hashTable[i] = new listNode("dummyfisrtName","dummylastName");
   }

  }

public  int Doit(String firstName){
  int val = 1;
  for(int i=0;i<firstName.length();i++){
    val = val*32+(int)firstName.charAt(i);
  }
  return Math.abs(val%bucketSize);
}

public listNode findSpot(int index,String firstName,String lastName){
 listNode dummy = hashTable[index];
 listNode spot = dummy;
 while(spot.next != null && spot.next.lastName.compareTo(lastName)<0 ){spot = spot.next;}
 if(spot.next != null && spot.next.lastName.compareTo(lastName)==0){
   while(spot.next != null && spot.next.lastName.compareTo(lastName)==0 && spot.next.firstName.compareTo(firstName)<0){spot = spot.next;}
 }
 
 return spot;

}

public void hashInsert(int index,String firstName,String lastName,FileWriter fw)throws IOException{
  String line = System.getProperty("line.separator");

  fw.write("enter hashInsert method. Performing hashInsert on firstName, lastName ");
  fw.write(line);
    listNode spot = findSpot(index,firstName,lastName);
    if(spot.next !=null && spot.next.lastName.compareTo(lastName)==0 && spot.next.firstName.compareTo(firstName)==0){fw.write("*** Warning, the record is already in the database!");}
    else{
      listNode newnode = new listNode(firstName,lastName);
      newnode.next = spot.next;
      spot.next = newnode;
    }
   
    fw.write(" After hashInsert operation :");

    printList(index,fw);
    fw.write(line);

  
}


public void hashDelete(int index, String firstName,String lastName,FileWriter fw)throws IOException{
  String line = System.getProperty("line.separator");

  fw.write("** Inside hashDelete method. Performing hashDelete on firstName, lastName ");
  fw.write(line);
  listNode spot = findSpot(index,firstName, lastName);
  if(spot.next == null){fw.write("*** Warning, the record is *not* in the database!");}
  else if(spot.next.lastName.compareTo(lastName) == 0 && spot.next.firstName.compareTo(firstName) == 0){
    listNode temp = spot.next;
    spot.next = temp.next;
    fw.write(" After hashDelete operation: ");
    printList(index,fw);
    fw.write(line);
  }
  else{fw.write("Something is wrong with the findSpot method!");}
  
}


public void hashRetrieval(int index,String firstName,String lastName,FileWriter fw)throws IOException{
  String line = System.getProperty("line.separator");
 
  fw.write("** Inside hashRetrieval. Performing hashRetrieval on firstName, lastName ");
  listNode spot = findSpot(index,firstName,lastName);
  fw.write(line);
  if(spot.next == null){
    fw.write("*** Warning, the record is *not* in the database!");
    fw.write(line);
    fw.write(line);

  }
   else if(spot.next.lastName.compareTo(lastName)==0 && spot.firstName.compareTo(firstName)==0){
    fw.write("Yes, the record is in the database!");
    fw.write(line);
    fw.write(line);
  }
  else {
    fw.write("Something is wrong with the findSpot method!");
    fw.write(line);
    fw.write(line);
  } 

  


}

public void printList(int index,FileWriter fw)throws IOException{
  String line = System.getProperty("line.separator");

  fw.write("hashTable[");
  
  fw.write(String.valueOf(index));
  fw.write("]:");
  listNode dummy = hashTable[index];
  listNode temp = dummy;
  fw.write("(");
  fw.write("dummyFirstName");
  fw.write(",");
  fw.write("dummylastName");
  if(temp.next != null){
    fw.write(",");
    fw.write(temp.next.firstName);
  }else{
    fw.write(",");
    fw.write("null");}
  fw.write(")");
  fw.write("-->");
  while(temp.next != null){
    dummy.printNode(temp.next,fw);
    temp = temp.next;
  }
  
  fw.write("null");
  fw.write(line);


  



 


}


public void informationProcesiing(File inFile,File outFile)throws IOException{

      String line = System.getProperty("line.separator");
      FileWriter fw = new FileWriter(outFile);
      fw.write("Enter informationProcessing method");
      fw.write(line);
      FileReader fr = new FileReader(inFile);
      Scanner input = new Scanner(fr);
      while(input.hasNext()){
        fw.write("the information we neen to deal with is:");
        String o = input.next();
        String first = input.next();
        String last = input.next();
        fw.write("(");
        fw.write(o);
        fw.write(",");
        fw.write(first);
        fw.write(",");
        fw.write(last);
        fw.write(")");

        fw.write(line);
        fw.write("the index which is going to te deal with is:");
        int in = Doit(first);
        fw.write(String.valueOf(in));
        fw.write(line);
        printList(in, fw);
        if(o.equals("+")){
          hashInsert(in,first,last,fw);
        }
        else if(o.equals("-")){
          hashDelete(in ,first,last,fw);
        }
        else if(o.equals("?")){
          hashRetrieval(in, first, last, fw);
        }
        else{
          fw.write("op is an unrecognize operation!");
          fw.write(line);
          fw.write(line);
        }
      }
      fw.close();

}

public void printHashTable(File outFile)throws IOException{
 
  FileWriter fw = new FileWriter(outFile);
  for(int i = 0;i<bucketSize;i++){
    printList(i,fw);
  }
  fw.close();
  
 
}


}
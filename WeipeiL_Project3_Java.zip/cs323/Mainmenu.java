package cs323;

import java.io.*;
import java.util.Scanner;
class Mainmenu {
  public static void main(String[] args) throws IOException{
    String input = args[0];
    String output1 = args[1];
    String output2 = args[2];
   
    
    File inFile = new File(input);
    File outFile2 = new File(output2);
    
    File outFile1 = new File(output1);
    
    System.out.print("please enter bucket size");
    Scanner reader = new Scanner(System.in);
    int n = reader.nextInt();
    reader.close();

    
    hashTable table = new hashTable();
    table.bucketSize = n;
    table.createHash();
   
  
    table.informationProcesiing(inFile,outFile2);
    table.printHashTable(outFile1);
    
  }
}

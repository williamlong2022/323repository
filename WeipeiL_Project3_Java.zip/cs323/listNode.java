package cs323;

import java.io.*;
public class listNode{
  String firstName;
  String lastName;
  listNode next;

  public listNode(String first,String last){
    firstName = first;
    lastName = last;
    next = null;
  }

  public void printNode(listNode node,FileWriter fw)throws IOException{
      try{
    
   
    fw.write("(");
    fw.write(String.valueOf(node.firstName));
    fw.write(",");
    fw.write(String.valueOf(node.lastName));
    if(node.next != null){
      fw.write(",");
      fw.write(String.valueOf(node.next.firstName));
    }else{
      fw.write(",");
      fw.write("Null");
    }
    fw.write(")");
    fw.write("-->");


    
   
    }
     catch (IOException e) {
  
            
          
           
                
        }
  }

}
